﻿
namespace Application
{
    public interface IApplicationActorProvider
    {
        IApplicationActor GetActor();
    }
}
