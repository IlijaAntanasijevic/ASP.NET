﻿namespace API.DTO
{
    public class FileUploadDto
    {
        public IFormFile File { get; set; }
    }
}
